package com.pi2.AutoEletricaApi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AutoEletricaApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
