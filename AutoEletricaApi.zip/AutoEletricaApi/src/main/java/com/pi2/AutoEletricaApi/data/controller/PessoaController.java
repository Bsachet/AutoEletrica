package com.pi2.AutoEletricaApi.data.controller;

import com.pi2.AutoEletricaApi.data.Pessoa;
import com.pi2.AutoEletricaApi.service.PessoaService;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class PessoaController {

    @Autowired
    private PessoaService pessoaService;
    
        @GetMapping("/pessoa")
    public List<Pessoa> getPessoas() {
        return pessoaService.getPessoas();
    }
    
        @PostMapping("/pessoa")
    public Pessoa savePessoa(@RequestBody Pessoa pessoaObj) {
        pessoaService.savePessoa(pessoaObj);
        return pessoaObj;
    }
    
      @GetMapping("/pessoa/{id}")
    public Pessoa getPessoa(@PathVariable int id) {
        Pessoa pessoaObj = pessoaService.getPessoa(id);
        if (pessoaObj == null) {
            throw new RuntimeException("Pessoa nao encontrada");
        }
        return pessoaObj;
    }
  
        @DeleteMapping("/pessoa/{id}")
    public String deletePessoa(@PathVariable int id) {
        pessoaService.deletePessoa(id);
        return "Pessoa deletada com o id: " + id;
    }
    
        @PutMapping("/pessoa")
    public Pessoa updatePessoa(@RequestBody Pessoa pessoaObj) {
        pessoaService.savePessoa(pessoaObj);
        return pessoaObj;
    }
}
