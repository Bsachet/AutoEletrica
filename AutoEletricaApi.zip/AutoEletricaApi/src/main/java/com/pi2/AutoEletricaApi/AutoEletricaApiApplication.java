package com.pi2.AutoEletricaApi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AutoEletricaApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(AutoEletricaApiApplication.class, args);
	}

}
